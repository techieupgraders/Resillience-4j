package com.resilience4j.rateLimiting.example.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.github.resilience4j.ratelimiter.annotation.RateLimiter;

/*In this example, 
backendA will allow 5 req/sec, 
backendB will alow 10 req/sec 
and all other requests will be limited by 15 req/sec (default configuration).
*/

@RestController
@RequestMapping("/rate-limiter")
public class RateLimitingSampleController {
	
	Logger logger = LoggerFactory.getLogger(RateLimitingSampleController.class);

	@RateLimiter(name = "backendA")
	@GetMapping("/message/a")
	public String getMessageA() {
		return "Message from backend A";
	}

	@RateLimiter(name = "backendB")
	@GetMapping("/message/b")
	public String getMessageB() {

		return "Message from backend B";
	}

	@RateLimiter(name = "backendc")
	@GetMapping("/message/c")
	public String getMessageC() {
		return "Message from backend C";
	}

}
