package com.resilience4j.rateLimiting.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Resillience4jRateLimitingExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Resillience4jRateLimitingExampleApplication.class, args);
	}

}
