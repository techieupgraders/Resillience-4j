package com.resilience4j.rateLimiting.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Resillience4jRateLimitingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
